# Workflows FCE27

As definições estão em `../src/workflows.json`. Cada pipeline é uma lista ordenada de etapas.
O motor executa as rotinas locais em `src/engine.js`; a interface aciona os pipelines em `src/app.js`.

Para adicionar uma etapa:
1. Inclua o nome da etapa no pipeline JSON.
2. Implemente uma função pura ou uma função de serviço no motor.
3. Conecte a etapa no despachante `runWorkflow`.
4. Atualize README e smoke tests.
