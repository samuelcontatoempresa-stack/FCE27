# FCE27 — Player Career Simulator

Aplicativo local de carreira de jogador de futebol, com interface em português, simulação de partidas, calendário, treino, evolução, mercado, tabelas, console de comandos e workflows.

## Como executar
**Não precisa instalar Node.js nem dependências.**
1. Extraia o ZIP.
2. Abra `index.html` em um navegador moderno (Chrome, Edge ou Firefox).
3. O progresso é salvo automaticamente no `localStorage` do navegador.

> Para evitar restrições de módulos em alguns navegadores ao abrir `file://`, execute um servidor local opcional:
> `python -m http.server 8000`
> e abra `http://localhost:8000`.

## Recursos implementados
- Navegação por Home, CT, Agenda, Clube, Elenco, Carreira, Transferências, Competições, Mundo, Mensagens, Configurações e Dev Console.
- Carreira inicial de Samuel Lopes no Cagliari.
- Treino individual, extras semanais, carga de treino e atributos.
- Calendário mensal com avanço de dias.
- Simulação de partida: pré-jogo, mentalidade, lances decisivos, intervalo, segundo tempo e pós-jogo.
- Estatísticas, metas, olheiros, contrato, tabela e mensagens.
- Salvamento automático, exportação/importação Base64 JSON.
- Console interno com comandos e três workflows.
- CI simples com verificação de sintaxe JavaScript e JSON.

## Console: lista de códigos
Digite os comandos na aba **Dev / Workflows**.

| Código | Ação |
|---|---|
| `/help` | Lista os comandos disponíveis |
| `SIM_DAYS_03` | Simula três dias |
| `SIM_DAYS_NN` | Simula NN dias (dois dígitos) |
| `SIM_TO_MATCH` | Avança até a data do próximo jogo |
| `TRN_SET_EXPLOSAO_PESADO` | Aplica treino Força e Explosão |
| `MATCH_TRIGGER_LANCE` | Abre lance decisivo; cria partida se necessário |
| `MATCH_SET_MENTALIDADE_PROTAGONISTA` | Aplica mentalidade Protagonista |
| `CAREER_ADD_OVR_02` | Adiciona 2 OVR, máximo 99 |
| `CAREER_ADD_FAMA_10` | Adiciona 10 pontos de fama, máximo 100 |
| `SAVE_EXPORT_CODE` | Abre exportação do save |
| `SAVE_IMPORT_CODE` | Abre importação do save |

Os comandos alteram o save local. Use cópias exportadas antes de testar alterações.

## Workflows
Definições declarativas ficam em `src/workflows.json`:
- `workflow_ciclo_semanal`: coletivo/individual, carga, calendário, olheiros e metas.
- `workflow_partida_completa`: pré-jogo, loop de minutos, lances, intervalo, segundo tempo, nota e recompensas.
- `workflow_evolucao_mercado`: desempenho, metas, valor e olheiros/propostas.

Na interface, abra **Dev / Workflows** e use os botões Executar. Para alterar etapas futuras, edite `src/workflows.json` e atualize a função `runWorkflow` em `src/app.js` para conectar novas etapas à lógica do motor em `src/engine.js`.

## Estrutura
```text
fce27-career-app/
├── index.html
├── README.md
├── src/
│   ├── styles.css
│   ├── app.js
│   ├── engine.js
│   ├── commands.json
│   └── workflows.json
├── workflows/
│   └── README.md
├── tests/
│   └── smoke-test.mjs
└── .github/workflows/
    └── ci-build.yml
```

## Limitações honestas
Este é um simulador original e independente, não um mod do EA SPORTS FC nem um produto oficial da EA. Os escudos, clubes, jogadores secundários, tabela e eventos são dados fictícios/de demonstração para a carreira inicial. O motor usa probabilidades locais e não pretende reproduzir o motor real de uma partida profissional. Os resultados podem variar a cada partida.
