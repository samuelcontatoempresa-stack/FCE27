import { readFile } from "node:fs/promises";
import vm from "node:vm";
import assert from "node:assert/strict";

const source = await readFile(new URL("../src/engine.js", import.meta.url), "utf8");
const transformed = source
  .replaceAll("export const ", "const ")
  .replaceAll("export function ", "function ")
  + "\nthis.api={DEFAULT_STATE,clone,advanceDays,applyTraining,runWeeklyWorkflow,addOvr,startMatch,resolveChance,simulateMinute,finishMatch};";
const context = { localStorage: { getItem:()=>null, setItem:()=>{} }, Date, Math };
vm.createContext(context);
vm.runInContext(transformed, context);
const e=context.api;
const s=e.clone(e.DEFAULT_STATE);
assert.equal(s.player.name,"Samuel Lopes");
e.advanceDays(s,3);
assert.equal(s.day,3);
const before=s.player.ovr;
e.addOvr(s,2);
assert.equal(s.player.ovr,before+2);
e.applyTraining(s,"FORÇA E EXPLOSÃO");
assert.ok(s.player.trainingLoad.physical>38);
e.startMatch(s,"Protagonista");
assert.equal(s.currentMatch.mentality,"Protagonista");
e.resolveChance(s,"shot");
assert.ok(s.currentMatch.decisions===1);
e.finishMatch(s);
assert.equal(s.currentMatch,null);
assert.ok(s.lastMatch);
console.log("FCE27 smoke tests: OK");
